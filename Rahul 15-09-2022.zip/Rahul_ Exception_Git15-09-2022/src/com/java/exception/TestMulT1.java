package com.java.exception;


public class TestMulT1 extends Thread {
	
	public void run() {
		System.out.println("print one");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestMulT1 task1=new TestMulT1();  
		TestMulT1 task2=new TestMulT1();  
		TestMulT1 task3=new TestMulT1();  
		  
		  task1.start();  
		  task2.start();  
		  task3.start();  

	}

}


