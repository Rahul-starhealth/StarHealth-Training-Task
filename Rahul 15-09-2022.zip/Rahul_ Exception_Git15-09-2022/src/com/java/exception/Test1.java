package com.java.exception;

public class Test1 {
	public void run() {
		System.out.println("test 1");
		
	}

	public void start() {
		// TODO Auto-generated method stub
		System.out.println("test 1");
		
	}

}
