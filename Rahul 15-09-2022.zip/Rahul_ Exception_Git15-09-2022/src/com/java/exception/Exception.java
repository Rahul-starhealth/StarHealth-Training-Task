package com.java.exception;

import java.io.FileReader;
import java.io.IOException;

public class Exception {
	public static void main(String[] args) {
		
		System.out.println("print first line");
		System.out.println("print second line");
		
		
		
		
//		try {
//			Scanner sc = new Scanner(System.in);
//			System.out.println("Enter your ATM Pin : ... ");
//			String pin  = sc.next();
//			if(pin.equals("1234")) {
//				System.out.println("Successfull!.. You withdrawal cash");
//			}
//			
//		} catch (Exception e) {
//			// TODO: handle exception
//			System.out.println(e);
//			System.out.println("please enter Corect Pin. Thank you");
//		}
//		finally {
//			System.out.println("thanks");
//		}
		
		
		
		
		
		 try(FileReader fr = new FileReader("E://Rahul.txt")) {
	         char [] a = new char[50];
	         fr.read(a);   
	         for(char c : a)
	         System.out.print(c);   
	      } catch (IOException e) {
	         e.printStackTrace();
	         System.out.println("path is not found");
	      }
		
		
		
	}


}
