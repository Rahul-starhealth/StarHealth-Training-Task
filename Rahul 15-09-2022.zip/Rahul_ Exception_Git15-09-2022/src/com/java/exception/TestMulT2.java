package com.java.exception;



public abstract class TestMulT2 implements Runnable {
public void run() {
		
	}

	public static void main(String[] args) {
 
	 Test1 t1=new Test1();  
		 Test2 t2=new Test2();  
		  
		  t1.start();  
		  t2.start();  

		
	}

}
