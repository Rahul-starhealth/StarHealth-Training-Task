package com.starhealth.pms.service;

import java.util.List;

import com.starhealth.pms.bean.Products;

public interface IproService {
	
	public int addProducts(Products obj);

	public int updateProducts(Products obj);

	public int deleteProducts(int sno);

	public Products selectProduct(int sno);

	public List<Products> selectAllProducts();

}
