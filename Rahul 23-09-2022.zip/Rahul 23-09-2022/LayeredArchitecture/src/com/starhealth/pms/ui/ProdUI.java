package com.starhealth.pms.ui;

import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

import com.starhealth.pms.bean.Products;
import com.starhealth.pms.exceptions.UserExcep;
import com.starhealth.pms.service.ServiceImp;

public class ProdUI {

	public static void main(String[] args) {

		ServiceImp service = new ServiceImp();

		Scanner scanner = new Scanner(System.in);

		boolean flag = true;

		while (flag) {

			System.out.println("1. Add Products");
			System.out.println("2. Update Products");
			System.out.println("3. Delete Products");
			System.out.println("4. Select Products");
			System.out.println("5. Select All Products");
			System.out.println("6. Exit");

			int choice = scanner.nextInt();

			switch (choice) {
			case 1:

				Products obj = inputData();

				boolean isValid = ServiceImp.validateInputs(obj);

				
				try {
					if (isValid) {
						int count = service.addProducts(obj);

						System.out.println(count + " record inserted successfully");
					} 
				throw new UserExcep("Please enter valid Inputs");}catch (UserExcep s) {
					s.printStackTrace();
					System.err.println("Please Enter valid Inputs");
				}
				
				/*
				 * else {
				 * 
				 * System.err.println("Please Enter valid Inputs");
				 * 
				 * }
				 */
				break;

			case 2:

				Products obj2 = inputData();

				int updateCount = service.updateProducts(obj2);

				System.out.println(updateCount + " record updated successfully");

				break;

			case 3:

				System.out.println("Enter Id to Delete One Record");
				int deleteId = scanner.nextInt();

				int deleteCount = service.deleteProducts(deleteId);

				System.out.println(deleteCount + " record deleted successfully");

				break;

			case 4:
				System.out.println("Enter Id to Select One Record");
				int searchId = scanner.nextInt();

				Products obj3 = service.selectProduct(searchId);

				System.out.println(obj3);

				break;

			case 5:

				List<Products> list = service.selectAllProducts();

				Stream<Products> stream = list.stream();

				stream.forEach(System.out::println);

				break;

			case 6:

				System.out.println("Thank You !!");

				flag = false;

				break;

			default:
				break;
			}

		}

	}

	public static Products inputData() {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter no");
		int sno = sc.nextInt();
		System.out.println("Enter product name");
		String proName = sc.next();
		System.out.println("Enter cost");
		int cost = sc.nextInt();
		

		Products prd = new Products();
		prd.setSno(sno);
		prd.setProName(proName);
		prd.setCost(cost);

		return prd;

	}

}