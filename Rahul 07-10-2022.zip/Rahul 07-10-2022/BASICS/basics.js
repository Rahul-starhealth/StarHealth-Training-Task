function normfun() { //normal function

    console.log("welcome...")

}

//anonymus function

var ano = function (name) {

    console.log("Am from Anonymus...")

}

ano("jashwanth")

//arrow function

var arr = function (uname, pass) {


    console.log(uname + " " + pass)

}

arr("jashwanth", "passwordddd")

//default function 

var defa = function(a=5,b){

    return a+b;
}

console.log(defa(10,10))


//spread function

function spf(name,...a){

    console.log(name,a)

}
spf("Jashwanth", 11,22,33,44,55,66)

//string functn 

function st(name){

    console.log("hello, welcome"+ " "+ name)

    console.log(name+" "+ `hello there !!
    welcome to the world ...`)


}

st("Jash")
