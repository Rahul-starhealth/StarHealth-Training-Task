class Student{

    constructor(){

        console.log("Object is created...")
    }

    method(){

        console.log("I am from method in student !!")
    }
}

var stu = new Student()

stu.method()

console.log(stu)