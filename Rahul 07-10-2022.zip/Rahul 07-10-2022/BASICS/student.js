var Student = /** @class */ (function () {
    function Student() {
        console.log("Object is created...");
    }
    Student.prototype.method = function () {
        console.log("I am from method in student !!");
    };
    return Student;
}());
var stu = new Student();
stu.method();
console.log(stu);
