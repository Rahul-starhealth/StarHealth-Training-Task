package training.java.opps.abstraction;

public class Main {
		  public static void main(String[] args) {
		    Subclass obj = new Subclass(); 
		    obj.child();
		    obj.sleep();
		  }
		

}
