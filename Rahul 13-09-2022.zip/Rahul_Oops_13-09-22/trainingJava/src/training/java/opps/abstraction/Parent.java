package training.java.opps.abstraction;

public abstract class Parent {
	
	public abstract void child();
	
	
	   public void sleep() {
	    System.out.println("sleeping");
	  }
	  
}
