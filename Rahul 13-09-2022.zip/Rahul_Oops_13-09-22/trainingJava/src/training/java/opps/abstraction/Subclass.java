package training.java.opps.abstraction;

class Subclass extends Parent {
	
	
	  public void child() {
	    
	    System.out.println("child method called");
	  }
	}