package training.java.opps.polymorphism;

public class Child  extends Parent{
	public void eat() {
		System.out.println("eating ");
	
	}
	@Override
	public void display() {
		System.out.println("parent class print display() method by override");
	}
	
	public static void sum() {
		System.out.println(" sum() method");
	}
	public static void sum(int a,int b) {
		System.out.println(a+b);
	}
	public static void sum(int a,int b, int c) {
		System.out.println(a+b + c);
	}
	
	public  static void main(String[] args) {
//		method overloading
		sum(2,3);
		sum(2,3, 3);
		
		
	}

}
