package training.java.opps.polymorphism;

public class SecondChild {
	
	public void eat() {
		System.out.println("eating ");
	}
	
	public static void main(String[] args) {
		
//		overiding method
		Parent obj1 = new Child();
		obj1.display();
		
		Parent obj2 = new Parent();
		obj2.display();
	}

}
