package training.java.opps.polymorphism;

public class Parent {
	
	public void eat() {
		System.out.println("Eating");
	}
	public void display() {
		System.out.println("parent class print display() method");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Parent a = new Parent();
		a.eat();
		Parent a1 = new Child();
		a1.eat();

	}

}
