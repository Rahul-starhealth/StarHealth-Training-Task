package com.starhealth.springdemo.repo;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;

public class DbCon {

	public static Connection getCon() {

		Connection conn = null;

		try {

			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/starhealth_db", "root", "J@sh1th24");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return conn;

	}

}
