import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'directives';

flag:boolean=true;

choice:string="";

names:string[] = ["Rahul"];

amount:number = 900;

}
