import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  @Input()
  cusInput:any="";


  @Output()
  eventObject: EventEmitter<String> = new EventEmitter();

  cusData:string="Payment done successfully...";

  sendData(){


    this.eventObject.emit(this.cusData);
    
  }


  constructor() { 
    
  }

  ngOnInit(): void {
  }

  showAmount(){

    alert(this.cusInput)
    
  }

}
