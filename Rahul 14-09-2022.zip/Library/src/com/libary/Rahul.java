package com.libary;

public class Rahul {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Enitity obj = new Enitity();
		obj.setAddress("Chennai");
		obj.setId(1);
		obj.setName("rahul j");
		
		Enitity obj1 = new Enitity("raman", 2, "pune");
		
		System.out.println(obj);
		
		System.out.println("Hashcode" + obj.hashCode());
		System.out.println("equals method : " + obj1.equals(obj));
	

	}
	
	

}
