package com.libary;

import java.time.LocalDate;
import java.time.LocalTime;

public class TimeClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LocalDate date = LocalDate.now();
		
		System.out.println(date);
		System.out.println(date.getDayOfMonth());
		System.out.println(date.getMonthValue());
		System.out.println(date.getDayOfWeek());
		System.out.println(date.getDayOfYear());
		System.out.println(date.minusMonths(12));
		System.out.println(date.plusYears(5));
		System.out.println(date.isLeapYear());

		
		LocalTime time = LocalTime.now();
		System.out.println(time);
		System.out.println(time.getHour());
		System.out.println(time.getMinute());
		System.out.println(time.getSecond());
		System.out.println(time.getNano());
		
		
		LocalTime timeof = LocalTime.of(10,43,18);
		System.out.println(timeof);
		System.out.println(timeof.getHour());
		System.out.println(timeof.getMinute());
		System.out.println(timeof.getSecond());
		System.out.println(timeof.getNano());
		

	}

}
