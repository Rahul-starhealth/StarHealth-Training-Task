package com.libary;

public class StringMethod {

	public static void main(String[] args) {
	
		String str1 = new String("Rahul");
		String str2 = " from starhealth ";
		
		System.out.println("string methods  are charAt  : ... " + str1.charAt(1));
		System.out.println("string methods  are concat  : ... " + str1.concat(str2));
		System.out.println("string methods  are  lowercase : ... " + str1.toLowerCase());
		System.out.println("string methods  are length  : ... " + str1.length());
		System.out.println("string methods  are lastindex  : ... " + str1.lastIndexOf(0));
		
		
		StringBuffer buffer = new StringBuffer("Star health ");
		System.out.println(buffer.isEmpty());
		System.out.println(buffer.replace(2, 7, "good"));
		System.out.println(buffer.reverse());
		System.out.println(buffer.append("insurance"));
		System.out.println(buffer.delete(1, 9));
		


	}

}
