package com.starhealth.springrestapi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.starhealth.springrestapi.entity.Students;
import com.starhealth.springrestapi.repo.IStudentRepo;

import antlr.collections.List;
@Service
public class StudentServiceImpl implements IStudentService {
	
	@Autowired
	IStudentRepo repo;

	@Override
	public Students addStudent(Students stud) {
		return repo.save(stud);
	}

	@Override
	public Students updateStudent(Students stud) {
		return repo.save(stud);
	}

	@Override
	public Students selectStudent(int sid) {
		return repo.findById(sid).orElse(null);
	}

	@Override
	public void deleteStudent(int sid) {
		
		repo.deleteById(sid);
	}
	
	public List selectAll() {
		return (List) repo.findAll();
		
	}

}
