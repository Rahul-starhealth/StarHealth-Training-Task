package com.starhealth.springrestapi.service;

import com.starhealth.springrestapi.entity.Students;

import antlr.collections.List;

public interface IStudentService {
	
	public Students addStudent(Students stud);
	public Students updateStudent(Students stud);

	public Students selectStudent(int sid);
	public void deleteStudent(int sid);
	
	public List selectAll();


}
